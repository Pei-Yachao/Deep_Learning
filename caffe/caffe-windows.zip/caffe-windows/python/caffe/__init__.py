from .pycaffe import Net, SGDSolver
